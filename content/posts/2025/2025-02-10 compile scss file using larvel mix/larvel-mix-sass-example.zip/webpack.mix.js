const mix = require('laravel-mix');

mix.sass('scss/style.scss', 'css/style.css');
mix.options({processCssUrls: false});

// Enable source maps for development
if (!mix.inProduction()) { mix.sourceMaps(); }